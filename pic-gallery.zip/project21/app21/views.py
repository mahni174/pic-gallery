from django.shortcuts import render
from django.shortcuts import redirect
from django.http import HttpResponse
from django.core.files.storage import default_storage
from django.core.files.base import ContentFile
from django.contrib.auth import login, authenticate
from django.contrib.auth.forms import UserCreationForm
from django.shortcuts import render_to_response
from PIL import Image
import datetime
import os
# Create your views here.


def view(request):
    return render(request, 'templates21.html',)


def upload(request):
    global pic
    x = datetime.datetime.now()
    x = str(x)
    pic = default_storage.save(x + 'file' + '.jpg', request.FILES['fileToUpload'])
    return redirect("/")


def rotate(request):
    degree = request.POST['rotate']
    try:
        degree = int(degree)
        image1 = Image.open("media/"+pic)
        image1.rotate(int(degree)).save("media/"+pic)
        return redirect("/renderer")
    except ValueError:
        return render(request, 'charerror.html', )


def resize(request):
    First = request.POST['First1']
    Second = request.POST['Second2']
    try:
        First = int(First)
        Second = int(Second)
        if (First == 0 or Second == 0):
            return render(request, 'error0resize.html', )
        else:
            mage1 = Image.open("media/"+pic)
            image1.thumbnail((First, Second))
            image1.save("media/"+pic)
            return redirect("/renderer")
    except ValueError:
        return render(request, 'charerror.html', )


def crop(request):
    crop1 = request.POST['1']
    crop2 = request.POST['2']
    crop3 = request.POST['3']
    crop4 = request.POST['4']
    try:
        crop1 = int(crop1)
        crop2 = int(crop2)
        crop3 = int(crop3)
        crop4 = int(crop4)
        if (crop3 <= crop1 or crop4 <= crop2):
            if (crop3 == crop1 == crop4 == crop2 == 0):
                return render(request, 'error0.html', )
            return render(request, 'error.html', )
        else:
            image1 = Image.open("media/"+pic)
            image1.crop(crop1, crop2, crop3, crop4).save("media/"+pic)
            return redirect("/renderer")
    except ValueError:
        return render(request, 'charerror.html', )


def bw(request):
    image1 = Image.open("media/"+pic)
    image1.convert(mode='L').save("media/"+pic)
    pic_1 = {'image': pic}
    return render(request, 'bw.html', pic_1)


def show(request):
    pic_2 = {'image': pic}
    return render(request, 'bw.html', pic_2)


def renderer(request):
    pic_3 = {'image': pic}
    return render(request, 'bw.html', pic_3)


def save(request):
    image1 = Image.open("media/" + pic)
    image1.save("media/save/" + pic)
    return redirect("/")


def gallery(request):
    path = "/home/mahsaniazi/project21/media/save/"
    img_list = os.listdir(path)
    img_list.sort()
    return render_to_response('sharemedia.html', {'images': img_list})

