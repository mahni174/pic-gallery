"""project21 URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from django.conf.urls import url
from app21 import views


urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.view),
    path('upload/', views.upload, name='upload'),
    path('rotate/', views.rotate, name='rotate'),
    path('resize/', views.resize, name='resize'),
    path('crop/', views.crop, name='crop'),
    path('bw/', views.bw, name='bw'),
    path('show/', views.show, name='show'),
    path('renderer/', views.renderer, name='renderer'),
    path('save/', views.save, name='save'),
    path('sharemedia/', views.gallery, name='sharemedia'),

]
if settings.DEBUG is True:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

